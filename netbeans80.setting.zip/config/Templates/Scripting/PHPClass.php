<?php
<#assign licenseFirst = "/* ">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

<#if namespace?? && namespace?length &gt; 0>
namespace ${namespace};
</#if>

/**
 * Description of ${name}
 *
 * @encoding ${encoding} 
 * @author ${user} 
 * @since ${.now?string("yyyy-MM-dd HH:mm (zzz)")} 
 * @version 0.1
 * @description 
 */
class ${name} {
    //put your code here
}
